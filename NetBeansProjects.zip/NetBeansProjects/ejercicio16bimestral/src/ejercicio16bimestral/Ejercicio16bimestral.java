package ejercicio16bimestral;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author sebas
 */
public class Ejercicio16bimestral {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
   
		double i;
		double rta;
		rta = 0;
		for (i=1;i<=100;i++) {
			rta = rta+1/i;
		}
		System.out.println("la respuesta es: "+rta);
	
        
        // TODO code application logic here
    }
    
}
