package monse;
import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author sebas
 */
public class Monse {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int num;
        System.out.println("Programa ");
        System.out.println("¿que día de febrero es hoy?");
        num=entrada.nextInt();
        if(num==7){
        System.out.println("ʜᴏʏ, 7 ᴅᴇ ғᴇʙʀᴇʀᴏ ᴅᴇʟ 2022 ᴄᴜᴍᴘʟᴇɴ ᴜɴ ᴀɴ̃ᴏ 8 ᴍᴇsᴇs ᴅᴇ ɴᴏᴠɪᴀᴢɢᴏ");
            System.out.println("ʜᴀɴ ᴘᴀsᴀᴅᴏ 610 ᴅɪ́ᴀs ᴅᴇsᴅᴇ ǫᴜᴇ ᴇᴍᴘᴇᴢᴀʀᴏɴ ᴀ sᴇʀ ᴘᴀʀᴇᴊᴀ");
            System.out.println("ʜᴀɴ ᴘᴀsᴀᴅᴏ 649 ᴅɪ́ᴀs ᴅᴇsᴅᴇ ǫᴜᴇ ᴇɴᴠɪᴀʀᴏɴ ᴇʟ ᴘʀɪᴍᴇʀ ᴍᴇɴsᴀᴊᴇ ♡");
            System.out.println("██████████████");
            System.out.println("█▒▒▒▒▒▒▒▒▒▒▒█");
            System.out.println("█▒▒▒██▒██▒▒▒█");
            System.out.println("█▒▒█▓▓█▓▓█▒▒█");
            System.out.println("█▒▒█▓▓▓▓▓█▒▒█");
            System.out.println("█▒▒▒█▓▓▓█▒▒▒█");
            System.out.println("█▒▒▒▒█▓█▒▒▒▒█");
            System.out.println("█▒▒▒▒▒█▒▒▒▒▒█");
            System.out.println("█▒▒▒▒▒▒▒▒▒▒▒█");
            System.out.println("██████████████");
        }
        // TODO code application logic here
    }
    
}
