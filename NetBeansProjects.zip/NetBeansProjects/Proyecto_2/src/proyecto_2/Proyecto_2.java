/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto_2;

/**
 *
 * @author sebas
 */
public class Proyecto_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     System.out.print("Nuevo Proyecto");
     System.out.println("Hello World");
     System.out.printf("%s%n%s%n","Martes","Introducción a la Programación");
// TODO code application logic here
    }
    
}
