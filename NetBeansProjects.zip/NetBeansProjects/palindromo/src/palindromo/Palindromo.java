/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package palindromo;
import java.util.Scanner;
/**
 *
 * @author sebas
 */
public class Palindromo {

    /**
     * @param args the command line arguments
     */
    
    public String eliminaEspacios(string cad){
     return cad.replace("")   
        
        
    }
            
            
    public static void main(String[] args) {
        
        
        
        // TODO code application logic here
    }
    
}
