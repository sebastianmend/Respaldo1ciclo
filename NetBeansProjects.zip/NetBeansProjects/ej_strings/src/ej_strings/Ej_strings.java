package ej_strings;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author sebas
 */
public class Ej_strings {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Metodos_strings obj = new Metodos_strings 
        
        int opc;
        
        do{
            opc=obj.menu();
            switch(opc){
                case 1:obj.carxcar(); 
                default:{
                    
                }
            
            }
            
            }while (opc!=0);
            
            
        }
        
        
        // TODO code application logic here
    }
 

