package division;
//programa para calcular la división entre dos números 
import java.util.Scanner;//el programa usa la clase scanner
 /* Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author sebas
 */
public class Division {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
       Scanner leer=new Scanner(System.in);  
       
        // TODO code application logic here
    }
    
}
